package com.cg.javaintro.bean;

public abstract class Shape {

	private static final float  PI=3.14f;
	
	
	
	


//	public abstract float calculateArea();



	public float getPi() {
		// TODO Auto-generated method stub
		return PI;
	}
	
}
