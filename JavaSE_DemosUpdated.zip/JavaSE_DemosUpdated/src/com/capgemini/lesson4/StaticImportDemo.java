package com.capgemini.lesson4;
import static java.lang.Math.*; //static import used here
public class StaticImportDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(sqrt(27));
		System.out.println(random());
		System.out.println(ceil(12.1));
		System.out.println(floor(12.9));
		System.out.println(round(12.5));
		System.out.println(pow(2,3));
	}

}
