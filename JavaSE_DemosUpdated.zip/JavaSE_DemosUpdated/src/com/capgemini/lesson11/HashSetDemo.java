package com.capgemini.lesson11;

import java.util.*;

class HashSetDemo {
	public static void main(String args[]) {
		// create a hash set
		Set hs = new HashSet();
		// add elements to the hash set
		hs.add("B");
		hs.add("A");
		hs.add("M");
		hs.add("E");
		hs.add("W");
		hs.add("V");
		
		Iterator i=hs.iterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
			
		}
	}
}
