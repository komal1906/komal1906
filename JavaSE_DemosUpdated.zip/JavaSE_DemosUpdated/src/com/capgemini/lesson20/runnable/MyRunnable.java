package com.capgemini.lesson20.runnable;

public class MyRunnable implements Runnable {

	@Override
	public void run() {
		

		if(Thread.currentThread().getName().equals("Thread-0"))
		{
		
        for(int row=2;row<4;row++){
			for(int num=1;num<=5;num++)
				System.out.print(row*num+" ");
			
			System.out.println("");
		}
		
		}
		else if(Thread.currentThread().getName().equals("Thread-1"))
		{
		
        System.out.println("Thread ended:::"+Thread.currentThread().getName());
		}		
	}

}
