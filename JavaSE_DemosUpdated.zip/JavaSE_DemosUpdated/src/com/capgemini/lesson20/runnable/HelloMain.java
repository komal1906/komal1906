package com.capgemini.lesson20.runnable;

public class HelloMain {

	public static void main(String[] args) {
		

	   Runnable hello = new HelloRunnable();
		Thread helloThread = new Thread(hello);
		//Thread helloThread=new Thread (new HelloRunnable()); 
	
		helloThread.start();
	
	}

}
