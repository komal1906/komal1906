package com.capgemini.lesson20.nonsynchronization;
public class Display {
	public synchronized void wish(String name) {
		for (int i = 0; i < 10; i++) {
			//System.out.print("Hello ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException interruptedException) {
				interruptedException.printStackTrace();
			}
			System.out.println("Hello "+name);
			System.out.println("\n");
		}
	}
}
