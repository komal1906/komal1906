package com.capgemini.lesson18.mock;

public class User {
String username, password;
}
