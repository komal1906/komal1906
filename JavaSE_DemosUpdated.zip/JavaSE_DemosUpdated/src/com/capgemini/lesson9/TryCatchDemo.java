package com.capgemini.lesson9;
class TryCatchDemo {

	public static void main(String a[]) {
		String str = null;
		try {
			str.equals("Hello");
		} catch(ArithmeticException ne) {
			str = new String("hello");
			System.out.println(str.equals("Hello"));
		}catch(Exception e)
		{
			System.out.println("Handling exception...");
		}
		finally {
			
			System.out.println("I aleays execute...");
		}
		System.out.println("Continuing in the program");
	}
}
